package com.aoxiang.springbootinit.service.impl;

import com.aoxiang.springbootinit.mapper.ChartMapper;
import com.aoxiang.springbootinit.model.entity.Chart;
import com.aoxiang.springbootinit.service.ChartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 *
 */
@Service
public class ChartServiceImpl extends ServiceImpl<ChartMapper, Chart>
    implements ChartService {

}




