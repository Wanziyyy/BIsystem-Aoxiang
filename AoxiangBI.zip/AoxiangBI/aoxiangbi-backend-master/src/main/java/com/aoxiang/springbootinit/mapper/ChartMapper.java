package com.aoxiang.springbootinit.mapper;

import com.aoxiang.springbootinit.model.entity.Chart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.aoxiang.springbootinit.model.entity.Chart
 */
public interface ChartMapper extends BaseMapper<Chart> {

}




