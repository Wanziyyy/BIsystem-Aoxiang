package com.aoxiang.springbootinit.mapper;

import com.aoxiang.springbootinit.model.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.aoxiangpi.springbootinit.model.entity.User
 */
public interface UserMapper extends BaseMapper<User> {

}




