package com.aoxiang.springbootinit.service;

import com.aoxiang.springbootinit.model.entity.Chart;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface ChartService extends IService<Chart> {

}
